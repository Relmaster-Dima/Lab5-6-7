/*package com.taxi.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Passenger {

    @Id
    private int passengerId;
    private String name;
    private String phoneNumber;
    private String email;
    private boolean deleted;

    // Геттер для passengerId
    public int getPassengerId() {
        return passengerId;
    }

    // Сеттер для passengerId
    public void setPassengerId(int passengerId) {
        this.passengerId = passengerId;
    }

    // Геттеры и сеттеры для других полей
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
}
*/